﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HesapMakinesi
{
    class Program
    {
        static void Main(string[] args)
        {
            Islem islem = SayıSecimi(); 
            IsaretSecme(islem); 
            Console.ReadLine();
        }

        private static Islem SayıSecimi()
        {
            Islem islem = new Islem();
            Console.WriteLine("Bir sayi giriniz:");
            islem.no1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Bir sayi giriniz:");
            islem.no2 = Convert.ToDouble(Console.ReadLine());
            return islem;
        }

        private static void IsaretSecme(Islem islem)
        {
            Console.WriteLine("Hangi işlemi yapmak istiyorsunuz: toplama: +, çıkarma: -, çarpma: *, bölme: /, yüzde: %");
            char isaret = Convert.ToChar(Console.ReadLine());
            if (isaret == '+')
                islem.topla();
            else if (isaret == '-')
                islem.cikar();
            else if (isaret == '*')
                islem.carp();
            else if (isaret == '/')
                islem.bol();
            else if (isaret == '%')
                islem.yuzde();
            else
            {
                Console.WriteLine("yanlış karakter girdiniz.");
                IsaretSecme(islem);
            }
        }

    }
    class Islem : IOperator, IValue
    {
        public double no1 { get; set; }
        public double no2 { get; set; }

        public void bol()
        {
            Console.WriteLine("Bölme Sonucu: " + no1 / no2);
        }

        public void carp()
        {
            Console.WriteLine("Çarpma Sonucu: " + no1 * no2);
        }

        public void cikar()
        {
            Console.WriteLine("Çıkarma Sonucu: " + (no1 - no2));
        }

        public void topla()
        {
            Console.WriteLine("Toplama Sonucu: " + (no1 + no2));
        }
        public void yuzde()
        {
            Console.WriteLine(no1 + " sayısının %" + no2 + " : " + (no1*no2/100) );
        }
    }
    interface IOperator
    {
        void topla();
        void cikar();
        void carp();
        void bol();
        void yuzde();
    }

    interface IValue
    {
        double no1 { get; set; }
        double no2 { get; set; }
    }
}
